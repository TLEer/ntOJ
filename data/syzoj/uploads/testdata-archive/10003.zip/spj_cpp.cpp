#include <iostream>
int main() {
  std::cout << 100 << std::endl;
  std::cerr << "OKay" << std::endl;
  return 0;
}
