#include<bits/stdc++.h>
using namespace std;

#define work system(s);
char s[1000];

const double n[]={15,1e3,1e5,1e5,1e5,1e5,1e5,1e5,1e5,1e5};
const double k[]={10,1e3,3e5,3e5,3e5,3e5,3e5,3e5,3e5,3e5};
const int o[]={0,0,0,0,0,0,0,0,1,1};
const int type[]={0,0,1,2,3,4,5,6,7,0};

int main(){
	for(int t=0;t<10;++t){
		fprintf(stderr,"%d\n",t);
		sprintf(s,"./data %d %d %d %d",(int)n[t],(int)k[t],o[t],type[t]);
		work;
		sprintf(s,"./e");
		work;
		sprintf(s,"rm e%d.in",t);
		work;
		sprintf(s,"rm e%d.ans",t);
		work;
		sprintf(s,"mv e.in e%d.in",t);
		work;
		sprintf(s,"mv e.out e%d.ans",t);
		work;
	}
}
