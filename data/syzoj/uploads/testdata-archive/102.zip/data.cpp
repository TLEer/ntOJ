#include<bits/stdc++.h>
using namespace std;

inline int f(int x,int y){
	return rand()%(y-x+1)+x;
}
int n,k,o,type;
vector<int> x;

int main(int argc,char*argv[]){
	freopen("e.in","w",stdout);
	n=strtol(argv[1],NULL,10);
	k=strtol(argv[2],NULL,10);
	o=strtol(argv[3],NULL,10);
	type=strtol(argv[4],NULL,10);
	srand(time(0)%clock()^time(0)*clock());

	n-=f(0,n/20);
	while(k){
		int a=1e9;
		for(int i=1;i<=8;++i)
			a=min(a,f(1,round(sqrt(k))));
		if(a<=1&&f(0,10)&&a<k)
			++a;
		if(a<=2&&f(0,10)&&a<k)
			++a;
		if(type==2)
			a=1;
		if(type==6)
			a=min(a,2);
		k-=a;
		x.push_back(a);
	}
	if(type==7)
		x.clear();
	random_shuffle(x.begin(),x.end());
	printf("%d %lu %d\n",n,x.size(),o);
	for(int i=1,x=f(1,1e9);i<=n;++i)
		printf("%d ",type==1?x:f(1,type==3?10:1e9));
	puts("");
	for(int i=2,fa;i<=n;++i){
		if(type==5||n>1e2&&f(1,20)<=3||n>1e4&&i>n*0.7)
			fa=i-1;
		else
			fa=f(1,i-1);
		printf("%d %d\n",fa,i);
	}
	while(!x.empty()){
		printf("%d %d ",type==4?1:f(1,type==3?10:1e9),x.back());
		for(int i=1;i<=x.back();++i)
			printf("%d ",f(1,n));
		puts("");
		x.pop_back();
	}
	return 0;
}
